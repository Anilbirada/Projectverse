-- Academic Relational Schema
CREATE TABLE records (id INT PRIMARY KEY, timestamp DATETIME);
